//package com.claudiusmbemba.irisdemo.helpers;
//
//import com.claudiusmbemba.irisdemo.models.NutritionixData;
//
///**
// * Created by jgadsby on 3/21/17.
// */
//
//public interface NutritionixListener {
//
//    void onSuccess(NutritionixData nutritionixData);
//    void onFailure(String error);
//}
